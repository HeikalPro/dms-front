# models.py
from sqlalchemy import Column, Integer, String, Text, DateTime, Identity, Text, bindparam, CLOB  
from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy import ForeignKey
from datetime import datetime, timezone
from sqlalchemy.dialects.oracle import VECTOR, VectorStorageFormat


Base = declarative_base()


class ContentMixin:
    @declared_attr
    def id(cls):
        return Column(Integer, primary_key=True, index=True)
    
    @declared_attr
    def content(cls):
        return Column(Text, nullable=False)
    
    @declared_attr
    def embedding(cls):
        return Column(Text, nullable=False)
    
    @declared_attr
    def source(cls):
        return Column(String(255), nullable=True)  

class SystemPrompt(Base):
    __tablename__ = "DOC_ASSISTANT_SYSTEM_PROMPTS"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=False, nullable=False)         # ✅
    content = Column(Text, unique=False, nullable=False)
    user_id = Column(Integer, ForeignKey("DOC_ASSISTANT_USERS.id"), nullable=False) 

class FileRecord(Base, ContentMixin):
    __tablename__ = "DOC_ASSISTANT_FILES2"
    file_id = Column(String(255), unique=True, nullable=False)      # ✅
    filename = Column(String(255), nullable=False)                  # ✅
    upload_type = Column(String(50), nullable=False, default="file")# ✅
    user_id = Column(Integer, ForeignKey("DOC_ASSISTANT_USERS.id"), nullable=False)
    source = Column(String(255))
    content = Column(Text)
    opentxt_storage_id = Column(Integer)  
    embedding =  Column(VECTOR(dim=1235, storage_format=VectorStorageFormat.FLOAT32), nullable=False)
    
class FileEmbeddings(Base):
    __tablename__ = "DOC_ASSISTANT_EMBEDDINGS"
    embedding_id = Column(String(255), unique=True, nullable=False, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_id = Column(String(255), ForeignKey("DOC_ASSISTANT_FILES2.file_id"), nullable=False)
    page_number = Column(Integer)
    opentxt_storage_id = Column(Integer, nullable=True)
    content = Column(Text, nullable=False)  
    embedding =  Column(VECTOR(dim=1235, storage_format=VectorStorageFormat.FLOAT32), nullable=False)

class ConversationRecord(Base):
    __tablename__ = "DOC_ASSISTANT_CONVERSATIONS"
    conversation_id = Column(String(255), primary_key=True, index=True)  # ✅
    history = Column(Text, nullable=False)
    user_id = Column(Integer, ForeignKey("DOC_ASSISTANT_USERS.id"), nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class User(Base):
    __tablename__ = "DOC_ASSISTANT_USERS"

    id= Column(Integer, Identity(start=1),  primary_key=True)
    username = Column(String(50), unique=True, nullable=False )
    email = Column(String(100), unique=True, nullable=True)
    hashed_password = Column(String(255), nullable=False)


