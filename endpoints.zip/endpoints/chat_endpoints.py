import json
import logging
import uuid
import asyncio
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from utils.chat.file_handler import get_selected_files
from utils.chat.settings import get_current_datetime_location#, client, MAX_TOKENS
from utils.chat.streaming import stream_response
from utils.chat.conversation import get_or_create_conversation, update_conversation
from utils.chat.llm_config import llm, get_dynamic_token_limits
from utils.chat.orch_bot import extract_needed_data, parse_chatbot_output
from utils.chat.file_updated import file_diff
from utils.knowledge_base_limit import divide_chunk, summarize_page
from database import get_db
from models import ConversationRecord
import tiktoken
from dotenv import load_dotenv
import os
import requests
import math
from utils.embedding_utils import get_embedding, get_embedding_old
import re
from sqlalchemy import text, bindparam 
from sqlalchemy.exc import SQLAlchemyError 
from sqlalchemy.orm import Session
from database import engine  # assumes engine is already defined
import numpy as np
from endpoints.user_endpoints import get_current_user
from models import User
load_dotenv()
logger = logging.getLogger(__name__)
# Initialize router
router = APIRouter()

LLAMA_API_KEY = os.getenv("LLAMA_API_KEY")
LLAMA_MODEL = "/mnt/data/llms/Llama-3.3-70B-Instruct"

 

# --- Logging Setup for Terminal Debugging ---
logger = logging.getLogger("chat endpoint")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def format_system_prompt(standalone_question, history, selected_file_ids, kb, system_message, db): 
    """Builds a structured full prompt combining system, knowledge base, history, and user question."""
    if selected_file_ids:
        file_context, file_names = get_selected_files(db, selected_file_ids)
    else: 
        file_context = None
        file_names = None

    current_date, current_time, current_location = get_current_datetime_location()

    formatted_history = ""
    if history:
        formatted_history = "\n".join(
            f"{msg['role'].capitalize()}: {msg['content']}" for msg in history if msg.get("content")
        )
    if kb:
    # Build final prompt as a single string
        full_prompt = f"""
            System
            You are AI document assistant, an advanced enterprise assistant developed by e&. Your task is to provide a clear and accurate response to the user's latest message based on the available context. Respond only to the new user message and avoid inventing prior questions or simulating dialogue. Be detailed, helpful, and accurate.
            Input Details:

            User Instructions:
            {system_message or 'None provided'}

            Files:
            {file_names or 'No files provided'}

            Knowledge Base Context:
            {kb or "No knowldge base provided"}

            Conversation History:
            {formatted_history or "No conversation History"}

            User Message:
            {standalone_question}

            System Instructions:
            Respond Only to the User's Latest Message:
            Use the provided context (knowledge base, files, and conversation history) to answer the user's query.
            Do not simulate dialogue or invent prior questions.
            Be Concise and Accurate.
            Provide a helpful response in a clear and concise manner.
            Avoid unnecessary elaboration or irrelevant information.
            Do not talk about religion, ploitics, people, +18 content, kiss, sex or any related context and LGPQT

            Output Format:
            Respond directly to the user's message.
            Ensure the response is complete and aligned with the context provided.
            Add citations one time at the end of you response only if you use data from Knowledge Base Context like file names and page numerbs.
            
            

            Example Outputs:
            Example 1:
            If the user asks, "What is the concept of black holes?" and relevant knowledge is available:
            "Black holes are regions of space where gravity is so strong that nothing, not even light, can escape. They form when massive stars collapse under their own gravity. File name: xyz and page number: x"
            Source: File Name, page numbers.

            Example 2:
            If the user says "Hi":
            "Hello! How can I assist you today?"
        

            Example 3:
            If the user asks a question but no relevant knowledge is available:
            "I'm sorry, I don't have enough information to answer your question. Could you provide more details?" 
            
                """
    else:
        full_prompt = f"""
            System
            You are AI document assistant, an advanced enterprise assistant developed by e&. Your task is to provide a clear and accurate response to the user's latest message based on the available context. Respond only to the new user message and avoid inventing prior questions or simulating dialogue. Be concise, helpful, and accurate.
            Input Details:

            User Instructions:
            {system_message or 'None provided'}

            Files:
            {file_names or 'No files provided'}



            Conversation History:
            {formatted_history or "No conversation History"}

            User Message:
            {standalone_question}

            System Instructions:
            Respond Only to the User's Latest Message:
            Use the provided context (knowledge base, files, and conversation history) to answer the user's query.
            Do not simulate dialogue or invent prior questions.
            Be Concise and Accurate.
            Provide a helpful response in a clear and concise manner.
            Avoid unnecessary elaboration or irrelevant information.
            Do not talk about religion, ploitics, people, sex or any related context and LGPQT

            Output Format:
            Respond directly to the user's message.
            Ensure the response is complete and aligned with the context provided.
           
            Example Outputs:
            Example 1:
            If the user asks, "What is the concept of black holes?" and relevant knowledge is available:
            Response:
            "Black holes are regions of space where gravity is so strong that nothing, not even light, can escape. They form when massive stars collapse under their own gravity. File name: xyz and page number: x"
            Source: File Name, page number.

            Example 2:
            If the user says "Hi":
            "Hello! How can I assist you today?"
        

            Example 3:
            If the user asks a question but no relevant knowledge is available
            "I'm sorry, I don't have enough information to answer your question. Could you provide more details?" 
            
                """

    return full_prompt




def refine_user_message(user_message, history, selected_file_ids, db):

    if selected_file_ids:
        file_context, file_names = get_selected_files(db, selected_file_ids)
    else: 
        file_context = None
        file_names = None

    # Format chat history into plain text (for completions endpoint)
    formatted_history = ""
    if history:
        formatted_history = "\n".join(
            f"{msg['role'].capitalize()}: {msg['content']}" for msg in history if msg.get("content")
        )
          
    full_prompt = f"""
            System:
            You are an AI agent orchestrator. Your task is to decide the next action to answer the user in this conversation. You must determine whether to respond based on the conversation history or fetch new data from the provided files. Additionally, you need to extract a clear standalone question from the user's input for semantic search and identify specific pages if mentioned. If no specific pages are requested, set the "pages" key to null.
            Here is the information you will use:
            - Conversation History: This contains the previous messages exchanged. If there is no history, it will say "No conversation history."
            - New User Message: This is the latest message from the user.
            - Knowledge Base Files: A list of files available for fetching data.
            Input Details:
            Conversation History:
            {formatted_history or "No conversation history"}
            New User Message:
            {user_message}
            Knowledge Base Files:
            {file_names}
            Instructions:
            1. Decide the Next Action:
            - If the user's query can be answered directly using the conversation history, set "next_action": "answer".
            - If the user's query requires new information from the provided files, set "next_action": "fetch data".
            - If the user's query requires updated content or a comparison between versions of two files, set "next_action": "updated content".
            - Only respond with one of the following values for "next_action": "answer", "fetch data", or "updated content".
            2. Extract a Standalone Question:
            - Generate a clear and concise standalone question based on the user's input. This will be used for semantic search if data fetching is required.
            3. Identify Pages:
            - If the user specifies particular pages, include them in the "pages" key (e.g., [5, 6, 7]).
            - If no pages are mentioned, set "pages" to null.
            - If the user requests all pages, include all page numbers.
            - if the user requests detailed explain of file, return 10 random pages number
            - If the user requests updated or different content between two files, include all page numbers.
            - If the user wants to compare two files without specifying page numbers, include the first 5 pages from each file (if available).
            - If selecting "updated content", do not include pages that have no updates.
        

            Output Format
            Provide your response like Examples are provided below:

            Example 1:
            If the user asks a follow-up question that requires data not in the conversation history:
            [
            "next_action": "fetch data",
            "standalone_question": "What is the user asking about?",
            "pages": null
            ]

            Example 2:
            If the user starts a conversation with "Hi":
            [
            "next_action": "answer",
            "standalone_question": "User greeting",
            "pages": null
            ]

            Example 3:
            If the user asks a question that can be answered directly using the conversation history:
            [
            "next_action": "answer",
            "standalone_question": "What is the user asking about?",
            "pages": null
            ]

            Example 4:
            If the user asks for specific pages, such as "Summarize pages 5-10":
            [
            "next_action": "fetch data",
            "standalone_question": "Summarize the content of the specified pages.",
            "pages": [5, 6, 7, 8, 9, 10]
            ]
            Example 5:
            If the user asks for updated content:
            [
            "next_action": "updated content",
            "standalone_question": "give me the updated content in the second version of file",
            "pages": [all pages numbers]
            ]

            Reminder
            Be explicit and clear in your decisions.
            Avoid ambiguous or overly complex responses.
        """    
    llm_response = llm(LLAMA_MODEL, full_prompt, 0, 40, 0.85, 300)
    return llm_response

def get_ai_response(prompt):
    """Queries AI model asynchronously and returns structured response."""
    try:
        llm_response = llm(LLAMA_MODEL, prompt, 0.3, 20, 0.8, 4000)
        return llm_response

    except json.JSONDecodeError:
            logging.error("Invalid JSON format in AI response.")
            return {"response": "I'm sorry, I couldn't process the response correctly."}
    except ValueError as ve:
        logging.error(f"ValueError: {ve}")
        return {"response": "AI response error: unexpected format."}
    except Exception as e:
        logging.error(f"Error in AI response: {e}")
        return {"response": "AI processing error. Please try again."}

@router.post("/update-partial")
async def update_partial_response(data: dict, db: Session = Depends(get_db)):
    conversation_id = data.get("conversationId")
    assistant_message = data.get("assistantMessage")
    user_message = data.get("userMessage")
    user_id = data.get("userId")  # Optional but safer

    if not conversation_id or not assistant_message or not user_message:
        raise HTTPException(status_code=400, detail="Missing required fields.")

    conversation = db.query(ConversationRecord).filter_by(
        conversation_id=conversation_id
    ).first()

    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found.")

    try:
        history = json.loads(conversation.history or "[]")
        # Append user and assistant messages
        for i in range(len(history) - 1, -1, -1):
            if history[i]["role"] == "assistant":
                history[i]["content"] = assistant_message
                break
        else:
            # no assistant yet (user hit Stop very early) � just append both
            history.append({"role": "user", "content": user_message})
            history.append({"role": "assistant", "content": assistant_message})

        conversation.history = json.dumps(history)
        db.commit()
        return {"status": "success"}
    except Exception as e:
        logging.error(f"Failed to update conversation: {e}")
        raise HTTPException(status_code=500, detail="Failed to update history.")

@router.post("/")
async def chat_endpoint(
    data: dict,
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    logger.info("🚀 Chat endpoint called")
    logger.debug("Incoming payload: %s", data)
 
    user_message = data.get("user_message")
    provided_conversation_id = data.get("conversation_id")
    selected_file_ids = data.get("selected_file_ids", [])
    selected_video_ids = data.get("selected_video_ids", [])
    web_search_enabled = data.get("web_search", False)
    system_message = data.get("system_message", "")
 
    if not user_message:
        logger.warning("Missing user_message in request")
        raise HTTPException(status_code=400, detail="User message is required.")
 
    user_id = current_user.id
    logger.info("User ID: %s", user_id)
 
    conversation, conversation_id, history = get_or_create_conversation(db, provided_conversation_id, user_id)
    logger.info("Conversation ID: %s", conversation_id)
 
    history = history or []
    file_context, file_names = get_selected_files(db, selected_file_ids)
 
    logger.debug("Refining message with history and files...")
    refined_message = refine_user_message(user_message, history, selected_file_ids, db)
    

    standalone_answer = "None"
    while standalone_answer == "None":
        standalone_answer = extract_needed_data(refined_message)
        
    logger.info("Standalone Answer: %s", standalone_answer)
 
    ai_response = ""
    KB = ""
 
    if standalone_answer["next_action"] == "updated content":
        logger.info("🧠 Action: updated content")
        try:
            with engine.connect() as conn:
                query = text("""
                    SELECT DISTINCT embedding_id, content, filename, page_number
                    FROM DOC_ASSISTANT_EMBEDDINGS
                    WHERE file_id IN :file_ids
                    AND page_number IN :page_numbers
                """).bindparams(
                    bindparam("file_ids", expanding=True),
                    bindparam("page_numbers", expanding=True)
                )
                params = {
                    "file_ids": selected_file_ids,
                    "page_numbers": standalone_answer["pages"]
                }
                result = conn.execute(query, params)
                rows = result.fetchall()
                logger.debug("Fetched rows: %d", len(rows))
 
                KB = file_diff(rows)
        except Exception as e:
            logger.exception("Error during 'updated content' processing")
 
    elif standalone_answer["next_action"] == "fetch data":
        logger.info("🧠 Action: fetch data")
        try:
            query_vec = get_embedding_old(user_message)
            oracle_vector_str = "[" + ",".join(map(str, query_vec)) + "]"
            file_id_binds = [f":file_id_{i}" for i in range(len(selected_file_ids))]
            file_id_filter = ", ".join(file_id_binds)
            top_k = 10
            lst = []
 
            if standalone_answer["pages"]:
                with engine.connect() as conn:
                    query = text("""
                        SELECT DISTINCT embedding_id, content, filename, page_number
                        FROM DOC_ASSISTANT_EMBEDDINGS
                        WHERE file_id IN :file_ids
                        AND page_number IN :page_numbers
                    """).bindparams(
                        bindparam("file_ids", expanding=True),
                        bindparam("page_numbers", expanding=True)
                    )
                    params = {
                        "file_ids": selected_file_ids,
                        "page_numbers": standalone_answer["pages"]
                    }
 
                    result = conn.execute(query, params)
                    rows = result.fetchall()
                    logger.debug("Fetched rows (pages filter): %d", len(rows))
 
                    if len(rows) > 10:
                        for row in rows:
                            summarized_page = summarize_page(row[1], row[2], row[3])
                            lst.append(summarized_page + "\n" + "______________________________________________")
                        KB = divide_chunk(lst)
                    else:
                        for row in rows:
                            KB += "\n" + row[2] + "\n" + row[1] + "\n" + "______________________________________________"
 
            else:
                with engine.connect() as conn:
                    query = text(f"""
                        SELECT embedding_id, content, filename,
                        vector_distance(TO_VECTOR(:embedding_str), embedding) AS similarity
                        FROM DOC_ASSISTANT_EMBEDDINGS
                        WHERE file_id IN :file_ids
                        ORDER BY similarity ASC FETCH FIRST :k ROWS ONLY
                    """).bindparams(bindparam("file_ids", expanding=True))
 
                    params = {
                        "embedding_str": oracle_vector_str,
                        "k": top_k,
                        "file_ids": selected_file_ids
                    }
 
                    result = conn.execute(query, params)
                    rows = result.fetchall()
                    logger.debug("Fetched rows (vector filter): %d", len(rows))
 
                    if len(rows) > 10:
                        for row in rows:
                            summarized_page = summarize_page(row[1], row[2], row[3])
                            lst.append(summarized_page + "\n" + "______________________________________________")
                        KB = divide_chunk(lst)
                    else:
                        for row in rows:
                            KB += "\n" + row[2] + "\n" + row[1] + "\n" + "______________________________________________"
 
        except SQLAlchemyError as e:
            logger.exception("SQLAlchemy error during vector search")
 
    logger.debug("Building system prompt...")

    system_prompt = format_system_prompt(user_message, history, selected_file_ids, KB, system_message, db)
    
    logger.info("Invoking AI response...")
    ai_response = await asyncio.to_thread(get_ai_response, system_prompt)
    logger.info("AI raw response received")
 
    paresed_ai_response = parse_chatbot_output(ai_response)
    logger.debug("Parsed AI Response: %s", paresed_ai_response)
 
    final_answer = ai_response
 
    headers = {
        "X-Conversation-ID": conversation_id,
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Expose-Headers": "X-Conversation-ID",
    }
 
    logger.info("📤 Returning StreamingResponse with conversation_id: %s", conversation_id)
    return StreamingResponse(
        stream_response(final_answer, db, conversation, user_message, conversation_id, history),
        media_type="text/markdown",
        headers=headers,
    )
