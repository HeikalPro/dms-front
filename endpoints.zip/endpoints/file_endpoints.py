# endpoints/file_endpoints.py
import uuid
import json
import numpy as np
import os
import logging
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from fastapi.responses import StreamingResponse
from database import get_db
from models import FileRecord, FileEmbeddings
from utils.file_utils import allowed_file, convert_to_text
from utils.embedding_utils import get_embedding, get_embedding_old
import array
from utils.chat.opentext import OpenTextClient
import io
from sqlalchemy.orm import Session
import tempfile
from io import BytesIO
from endpoints.user_endpoints import get_current_user
from models import User
import requests
from jose import JWTError, jwt
import time
import random
router = APIRouter()

SECRET_KEY = os.getenv("SECRET_KEY")
# In-memory storage and FAISS index setup (for example purposes)
embedding_store = {}  # {file_id: {"filename": ..., "text": ..., "embedding": [...]}}
embedding_dim = 1536  # Embedding dimension
import faiss
faiss_index = faiss.IndexFlatL2(embedding_dim)
faiss_file_ids = []



@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)  # ✅ secure user retrieval
):
    if not allowed_file(file.filename):
        raise HTTPException(status_code=400, detail="File format not allowed.")
 
    # Save file to temporary disk
    with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file.filename}") as temp:
        content = await file.read()
        temp.write(content)
        temp_path = temp.name
 
    # Upload to OpenText
    # try:
    #     client = OpenTextClient()
    #     token = client.get_token()
    #     upload_id = client.upload_document(file_path=temp_path, name=file.filename)
    # except Exception as e:
    #     os.remove(temp_path)
    #     raise HTTPException(status_code=500, detail=f"Error saving file to OpenText: {str(e)}")
    # finally:
    #     if os.path.exists(temp_path):
    #         os.remove(temp_path)
 
    # Convert to text
    try:
        text = convert_to_text(file)
        total_pages = len(text)
        logging.info(f"✅ File converted: {file.filename}, pages={total_pages}")
    except Exception as e:
        logging.error(f"❌ Conversion error for {file.filename}: {e}")
        raise HTTPException(status_code=500, detail=f"Error converting file: {str(e)}")
 
    # Save FileRecord
    try:
        file_id = str(uuid.uuid4())
        upload_id = int(time.time()*1000) + int(random.randint(1, 100))
        record = FileRecord(
            file_id=file_id,
            filename=file.filename,
            upload_type="file",
            user_id=current_user.id,
            source=str(total_pages),
            content=str(text),
            opentxt_storage_id=upload_id,
            embedding=array.array('f', [0.1, 0.2])  # placeholder
        )
        db.add(record)
        db.commit()
        db.refresh(record)
    except Exception as e:
        db.rollback()
        logging.error(f"❌ DB error saving file record: {e}")
        raise HTTPException(status_code=500, detail=f"Error saving file record: {str(e)}")
 
    # Generate Embeddings
    try:
        embeddings = get_embedding(text)
        for page_number, (stmn, emb) in enumerate(zip(text, embeddings), start=1):
            try:
                emb_record = FileEmbeddings(
                    embedding_id=str(uuid.uuid4()),
                    filename=file.filename,
                    file_id=file_id,
                    content=stmn,
                    page_number=page_number,
                    embedding=emb,
                    opentxt_storage_id=upload_id
                )
                db.add(emb_record)
                db.commit()
            except Exception as e:
                db.rollback()
                logging.error(f"❌ Failed to save embedding: {e}")
                raise HTTPException(status_code=500, detail=f"Error saving embedding: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating embeddings: {str(e)}")
 
    return JSONResponse(content={"file_id": file_id, "filename": file.filename})

@router.get("/user/files")
def list_user_files(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)):

    try:
        file_records = db.query(FileRecord).filter(FileRecord.user_id == current_user.id).all()
        files = [
            {
                "file_id": fr.file_id,
                "filename": fr.filename,
                "upload_type": fr.upload_type,
                "source": fr.source,
                "text": fr.content
            } for fr in file_records
        ]
        return JSONResponse(content={"files": files})
    except Exception as e:
        logging.error(f"Error fetching user files: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching files.")

@router.delete("/delete/{file_id}")
async def delete_file(
    file_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    file_record = db.query(FileRecord).filter(
        FileRecord.file_id == file_id,
        FileRecord.user_id == current_user.id  # ✅ restrict to user's own files
    ).first()
 
    if not file_record:
        raise HTTPException(status_code=404, detail="File not found.")
 
    # opentext_id = file_record.opentxt_storage_id
    # try:
    #     client = OpenTextClient()
    #     token = client.get_token()
    #     client.delete_document(opentext_id)
    # except Exception as e:
    #     logging.warning(f"OpenText deletion failed: {e}")
 
    db.query(FileEmbeddings).filter(FileEmbeddings.file_id == file_id).delete()
    db.delete(file_record)
    db.commit()
 
    return JSONResponse(content={"message": "File deleted successfully", "file_id": file_id})

@router.get("/preview/{file_id}")
def preview_file_pages(
    file_id: str,
    token: str = Query(...),
    db: Session = Depends(get_db)
):
    try:
        # Step 1: Validate token
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            user_id: Optional[int] = payload.get("user_id")
            if not user_id:
                raise ValueError("Missing user_id in token")
        except Exception as e:
            logging.error(f"Token validation failed: {e}")
            raise HTTPException(status_code=401, detail="Invalid or expired token")
 
        # Step 2: Fetch file & validate ownership
        file_entry = db.query(FileRecord).filter_by(file_id=file_id, user_id=user_id).first()
        if not file_entry:
            raise HTTPException(status_code=404, detail="File not found")
 
        opentext_id = file_entry.opentxt_storage_id
        if not opentext_id:
            raise HTTPException(status_code=400, detail="Missing OpenText storage ID")
 
        # Step 3: Call OpenText safely
        client = OpenTextClient()
        try:
            ot_token = client.get_token()
            file_bytes = client.download_document(opentext_id)
        except requests.exceptions.Timeout:
            logging.warning("OpenText service timed out.")
            raise HTTPException(status_code=504, detail="File preview service timeout")
        except requests.exceptions.RequestException as e:
            logging.error(f"OpenText service error: {e}")
            raise HTTPException(status_code=502, detail="Failed to fetch file from OpenText")
 
        # Step 4: Return the file as streaming PDF
        filename = file_entry.filename or "preview.pdf"
        return StreamingResponse(
            BytesIO(file_bytes),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'inline; filename="{filename}"',
                "Content-Length": str(len(file_bytes)),
                "X-Content-Type-Options": "nosniff"
            }
        )
 
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.exception(f"Unhandled error in preview_file_pages: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve file preview.")

@router.get("/serve-file/{file_id}", response_class=StreamingResponse) 
def serve_uploaded_file(file_id: str, db: Session = Depends(get_db)):
    

    try:
        # Step 1: Get file metadata
        file_entry = db.query(FileRecord).filter_by(file_id=file_id).first()
        if not file_entry:
            print("cannot find the file_id")
            raise HTTPException(status_code=404, detail="File not found.")

        opentext_id = file_entry.opentxt_storage_id
        if not opentext_id:
            raise HTTPException(status_code=400, detail="Missing OpenText storage ID.")

        client =  OpenTextClient()
        token = client.get_token()
        download = client.download_document(opentext_id)
        
        file_bytes = download
        
        file_stream = io.BytesIO(file_bytes)
        print("download bytes", len(file_bytes))
        return StreamingResponse(file_stream, media_type="application/pdf",
        headers = {"Content-Dispostion": f'inline; filename="{file_entry.filename}"'}
        
        )

    except Exception as e:
        logging.error(f"Error in preview_file_pages: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve file preview.")
