# config.py
import os
import logging
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

LLAMA_API_BASE = os.getenv("LLAMA_API_BASE") 
LLAMA_API_KEY = os.getenv("LLAMA_API_KEY")
LLAMA_MODEL = os.getenv("LLAMA_MODEL", "meta-llama/Meta-Llama-3-70B-Instruct")

if not LLAMA_API_BASE:
    raise ValueError("LLAMA_API_BASE not set in environment variables")

# Optional: simple test to confirm base URL is reachable
try:
    health_check = requests.get(LLAMA_API_BASE, timeout=3)
    if not health_check.ok:
        logging.warning("LLaMA API base reachable, but response not OK.")
except Exception as e:
    logging.error(f"Unable to reach LLaMA API base: {e}")

# Expose config
__all__ = ["LLAMA_API_BASE", "LLAMA_API_KEY", "LLAMA_MODEL"]


