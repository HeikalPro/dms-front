import uvicorn
import logging
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import sys
from endpoints import (
    file_endpoints,
    conversation_endpoints,
    chat_endpoints,
    prompts_endpoints,
    login_endpoints,
    user_endpoints  
)
logger = logging.getLogger("uvicorn.error")
# Configure logging to output to a file named "app.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)


app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(file_endpoints.router, prefix="/files", tags=["files"])
app.include_router(conversation_endpoints.router, prefix="/conversations", tags=["conversations"])
app.include_router(prompts_endpoints.router, prefix="/prompts", tags=["prompts"])
app.include_router(chat_endpoints.router, prefix="/chat", tags=["chat"])
app.include_router(login_endpoints.router)
app.include_router(user_endpoints.router, prefix="/user",tags=["users"])

# Custom exception for demonstration
class ValidationError(Exception):
    def __init__(self, message: str):
        self.message = message

# Exception handler for the custom ValidationError
@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    logger.error(f"Validation error: {exc.message}")
    return JSONResponse(
        status_code=422,
        content={"detail": f"Validation Error: {exc.message}"}
    )

# Root endpoint
@app.get("/")
async def read_root():
    logger.info("Root endpoint accessed")
    print("Root endpoint accessed____")
    return {"message": "Hello, YouTube!"}

# Global error handler middleware
@app.middleware("http")
async def catch_exceptions_middleware(request: Request, call_next):
    try:
        response = await call_next(request)
        # Check if response status code indicates an error and log it
        if response.status_code >= 400:
            logger.warning(f"Request to {request.url} returned status {response.status_code}")
        return response
    except HTTPException as http_exception:
        logger.error(f"HTTP error occurred: {http_exception.detail}")
        return JSONResponse(status_code=http_exception.status_code, content={"detail": http_exception.detail})
    except Exception as e:
        logger.exception("Unhandled exception occurred")
        return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

if __name__ == "__main__":
    logger.info("Starting FastAPI application")
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
