import os
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
from models import Base  # Your declarative models
import oracledb

# ------------------------------------------------------------------
# 1. Enable thick mode for Oracle DB
# ------------------------------------------------------------------
oracledb.init_oracle_client(lib_dir="C:\\Program Files\\Oracle Client for Microsoft Tools")

# ------------------------------------------------------------------
# 2. Load environment variables
# ------------------------------------------------------------------
load_dotenv()

# Read values from environment variables
user = os.getenv("ORACLE_USER")
password = os.getenv("ORACLE_PASSWORD")
host = os.getenv("ORACLE_HOST")
port = os.getenv("ORACLE_PORT")
service_name = os.getenv("ORACLE_SERVICE_NAME")

# ------------------------------------------------------------------
# ------------------------------------------------------------------
# 3. Connection URL
# -----------------------------------------------------------------

DATABASE_URL = f"oracle+oracledb://{user}:{password}@{host}:{port}/?service_name={service_name}"

# ------------------------------------------------------------------
# 4. Engine
# ------------------------------------------------------------------
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,   # Avoids connection issues with idle APIs
    pool_recycle=3600,    # Optional: force reconnect every hour
    echo=False            # Set to True to log raw SQL queries
)

# ------------------------------------------------------------------
# 5. Session Factory
# ------------------------------------------------------------------
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """
    Dependency to provide a database session.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ------------------------------------------------------------------
# 6. Create Tables (Development Only)
# ------------------------------------------------------------------
# In production, use Alembic for migrations.
#Base.metadata.create_all(bind=engine)
sql = """
ALTER USER ahmheikal QUOTA UNLIMITED ON USERS
"""
# ------------------------------------------------------------------
# 7. Test Connection
# ------------------------------------------------------------------
# try:
#     with engine.connect() as conn:
#         inspector = inspect(engine)
#         table_names = inspector.get_table_names()
#         for i in table_names:
#             print(i)
# except Exception as e:
#     print("Connection failed:", e)

try:
    with engine.connect() as conn:
        result = conn.execute(text(sql))
        for row in result:
            print(row)
        print(result)
except Exception as e:
    print("Connection failed:", e)