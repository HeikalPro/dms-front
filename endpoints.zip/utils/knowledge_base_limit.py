import os
from dotenv import load_dotenv
import requests
from utils.chat.llm_config import llm
load_dotenv()
LLAMA_MODEL = "/mnt/data/llms/Llama-3.3-70B-Instruct"


def summarize_page(content, file_name, page_number):
    full_prompt = f"""
        You are an assistant specialized in content summarization. Your task is to analyze the provided content and return a concise, professional summary. Ensure the summary captures the key points and avoids unnecessary repetition or conversational elements. Format your response as follows:

        File Name: [file_name]
        Page Number: [page_number]
        Summary:
        [Summarized content]

        Here is the content to summarize:
        File Name: {file_name}
        Page Number: {page_number}
        Content:
        {content}
        """
    ai_response = llm(LLAMA_MODEL, full_prompt, 0, 40, 0.85, 75)
    return ai_response

def divide_chunk(lst):
    n = len(lst)
    k = 10
    avg = n // k
    rem = n % k

    start = 0
    chunks = []

    for i in range(k):
        end = start + avg + (1 if i < rem else 0)
        if start < n:
            chunks.append(lst[start:end])
        start = end 

    result_string = ''.join(str(item) for sublist1 in chunks for sublist2 in sublist1 for item in sublist2)
    return result_string



