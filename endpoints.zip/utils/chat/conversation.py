import json
import uuid
from models import ConversationRecord

def get_or_create_conversation(db, provided_conversation_id, user_id):
    # Try to fetch conversation only if both ID and user_id are provided
    conversation = None
    if provided_conversation_id:
        conversation = db.query(ConversationRecord).filter_by(
            conversation_id=provided_conversation_id,
            user_id=user_id
        ).first()

    if conversation:
        conversation_id = conversation.conversation_id
        history = json.loads(conversation.history)
    else:
        conversation_id = str(uuid.uuid4())
        conversation = ConversationRecord(
            conversation_id=conversation_id,
            history="[]",
            user_id=user_id  
        )
        db.add(conversation)
        db.commit()
        history = []

    return conversation, conversation_id, history


def update_conversation(db, conversation, history):
    conversation.history = json.dumps(history)
    db.add(conversation)
    db.commit()
