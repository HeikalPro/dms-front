from collections import defaultdict
import difflib

def file_diff(rows):
    page_content = defaultdict(dict)

    for id, text, filename, page in rows:
        page_content[page][filename] = text

    for page_num, versions in page_content.items():
        if len(versions) >= 2:
            files = list(versions.keys())
            text1 = versions[files[0]]
            text2 = versions[files[1]]

            diff = list(difflib.unified_diff(
                text1.splitlines(), text2.splitlines(),
                fromfile=files[0], tofile = files[1], lineterm = ''
            ))

            real_diff = [
                line for line in diff
                if (line.startswith(('+', '-')) and not line.startswith(('+++', '---')))
            ]

            #diff.append(str(page_num))
            if diff:
                X = "\n".join(diff) 
                return  X + f"\npage number: {str(page_num)}"