import requests
import os
from dotenv import load_dotenv

load_dotenv()
LLAMA_API_KEY = os.getenv("LLAMA_API_KEY")

def llm(LLAMA_MODEL, full_prompt, temperature, top_k, top_p, max_tokens):
    payload = {
                "model": LLAMA_MODEL,
                "prompt": full_prompt,
                "temperature": temperature,
                "top_k": top_k,
                "top_p": top_p,
                "max_tokens": max_tokens,   
                "stream": False
            }

    headers = {
        "Content-Type": "application/json"
    }
    if LLAMA_API_KEY:
        headers["Authorization"] = f"Bearer {LLAMA_API_KEY}"

    response = requests.post(
                LLAMA_API_KEY,
                headers=headers,
                json=payload
            )

    if response.ok:
            result = response.json()
            response_content = result["choices"][0]["text"]
            return response_content

def rough_token_estimate(text: str) -> int: 
    """Estimate number of tokens from string length."""
    return int(len(text) / 3.5)  # Rough: 1 token ≈ 3.5 characters

def get_dynamic_token_limits(kb: str, context_limit: int = 4096,
                             reserved_for_prompt: int = 512,
                             reserved_for_response: int = 512) -> dict:
    """
    Calculate how many tokens can be used from the KB
    while keeping space for prompt and model response.

    Returns:
        {
            "estimated_kb_tokens": int,
            "max_kb_tokens": int,
            "kb_truncated": str
        }
    """
    estimated_kb_tokens = rough_token_estimate(kb)
    max_kb_tokens = context_limit - reserved_for_prompt - reserved_for_response

    if estimated_kb_tokens <= max_kb_tokens:
        return {
            "estimated_kb_tokens": estimated_kb_tokens,
            "max_kb_tokens": max_kb_tokens,
            "kb_truncated": kb
        }
   
    # Truncate kb based on rough token estimate
    max_chars = int(max_kb_tokens * 3.5)
    truncated_kb = kb[:max_chars]

    return {
        "estimated_kb_tokens": estimated_kb_tokens,
        "max_kb_tokens": max_kb_tokens,
        "kb_truncated": truncated_kb
    }
