import requests
import logging
from bs4 import BeautifulSoup
from utils.chat.settings import SEARXNG_URL
import aiohttp

def query_searxng(query: str) -> str:
    if not query.strip():
        return "No valid search query provided."

    params = {"q": f"{query} in Egypt", "safesearch": 0}
    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        response = requests.get(SEARXNG_URL, params=params, headers=headers, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f"SearxNG request failed: {e}")
        return "No external search results found."

    soup = BeautifulSoup(response.text, "html.parser")
    results = [f"- {res.get_text(strip=True)}" for res in soup.select('.result')[:10]]

    return "\n".join(results) if results else "No external search results found."
