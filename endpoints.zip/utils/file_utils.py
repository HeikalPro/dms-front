import os
import tempfile
import json
import multiprocessing
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed
import PyPDF2
import docx
from fastapi import HTTPException
import os
import tempfile
import multiprocessing
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed
from fastapi import HTTPException
from pdf2image import convert_from_bytes
import pytesseract
from docx import Document
import logging
import platform
import logging
import platform
import shutil
from pathlib import Path
from typing import List
import fitz  # PyMuPDF
import pytesseract
from pdf2image import convert_from_bytes
from PIL import Image
from fastapi import HTTPException
from typing import List
import pytesseract
from fastapi import HTTPException
from pdf2image import convert_from_bytes, exceptions as pdf2img_exc
from PIL import Image
import subprocess
import os
import tempfile
import uuid
import subprocess
import math
from io import BytesIO

# For PPT/PPTX support.
try:
    from pptx import Presentation
except ImportError:
    Presentation = None

poppler_path = None
# Determine the optimal number of workers based on CPU cores
if platform.system() == "Windows":
    pytesseract.pytesseract.tesseract_cmd = (
        r"C:\\Users\\ahmheikal\\AppData\\Local\\Programs\\Tesseract-OCR\\tesseract.exe"
    )
    poppler_path = r"C:\Users\ahmheikal\Downloads\Release-24.08.0-0\poppler-24.08.0\Library\bin"
else:  # Linux, Docker, WSL, etc.
    pytesseract.pytesseract.tesseract_cmd = (
        shutil.which("tesseract") or "/usr/bin/tesseract"
    )
num_workers = min(2, multiprocessing.cpu_count())
print ("num_workers:",num_workers)
MAX_FILE_SIZE = 300 * 1024 * 1024  # 300MB

# Allowed file types
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'pptx', 'doc', "txt"}

def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def convert_to_text(file) -> str:
    try:
        file.file.seek(0)  # ✅ Make sure to start reading from the beginning
        content = file.file.read()
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail="File exceeds max allowed size (25MB)")

        ext = file.filename.rsplit('.', 1)[1].lower()
        print(f"[DEBUG] Received file: {file.filename} (type: {ext}, size: {len(content)} bytes)")

        if ext == "txt":
            decoded_text = content.decode("utf-8")
            return split_text_into_chunks(decoded_text, chunk_size=500, overlap=50)
        elif ext == "pdf":
            return convert_pdf(content)
        elif ext == "docx" or ext == "doc":
            pdf_path = convert_docx_bytes_to_pdf_linux(content)
            with open(pdf_path, "rb") as f:
                pdf_bytes = f.read()
                os.remove(pdf_path)
            return convert_pdf(pdf_bytes) 
        elif ext in ("ppt", "pptx"):
            return convert_ppt(content, ext)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
    except Exception as e:
        print(f"[ERROR] File processing failed for {file.filename}: {e}")
        raise HTTPException(status_code=500, detail=f"Error processing file: {e}")

def split_text_into_chunks(text: str, chunk_size=500, overlap=50):
    words = text.split()
    chunks = []
 
    i = 0
    while i < len(words):
        chunk = words[i:i + chunk_size]
        chunks.append(" ".join(chunk))
        i += chunk_size - overlap  # move forward with overlap
 
    return chunks

def convert_docx(content) -> str:
    try:
        # Wrap the byte content in a BytesIO object
        docx_file = BytesIO(content)

        # Load the DOCX content into a Document object
        doc = Document(docx_file)

        # Extract text from the document
        text = [para.text for para in doc.paragraphs]

        return text
    except Exception as e:
        print(f"[ERROR] Error converting DOCX file: {e}")
        raise HTTPException(status_code=500, detail="Error processing DOCX file")


def convert_docx_bytes_to_pdf_linux(content: bytes) -> str:
    """
    Converts a DOC or DOCX file (in bytes) to PDF using LibreOffice on Linux.
    Returns:
        str: Path to the converted PDF file.
    """
    # Determine extension (basic signature check)
    ext = ".docx"
    if content.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'):
        ext = ".doc"
 
    # Save to temp DOC/DOCX file
    with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp_doc:
        tmp_doc.write(content)
        tmp_doc_path = tmp_doc.name
 
    output_dir = tempfile.gettempdir()
    pdf_filename = os.path.splitext(os.path.basename(tmp_doc_path))[0] + ".pdf"
    output_pdf_path = os.path.join(output_dir, pdf_filename)
 
    try:
        # Run LibreOffice CLI
        subprocess.run([
            "libreoffice", "--headless", "--convert-to", "pdf",
            "--outdir", output_dir, tmp_doc_path
        ], check=True)
 
        return output_pdf_path
 
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] LibreOffice failed: {e}")
        raise
    
def convert_ppt(content: bytes, ext: str) -> str:
    """
    Extract text from PPT/PPTX file content.
    Handles both `.ppt` and `.pptx`.
    """
    try:
        if ext == '.ppt':
            # Save content to a temporary .ppt file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.ppt') as temp_ppt:
                temp_ppt.write(content)
                ppt_path = temp_ppt.name
 
            # Convert .ppt to .pptx using unoconv (LibreOffice must be installed)
            pptx_path = ppt_path + 'x'
            subprocess.run(['unoconv', '-f', 'pptx', ppt_path], check=True)
 
            # Load the converted .pptx content
            with open(pptx_path, 'rb') as f:
                content = f.read()
 
            # Clean up temp files
            os.remove(ppt_path)
            os.remove(pptx_path)
 
        # Continue with python-pptx parsing
        ppt_file = BytesIO(content)
        presentation = Presentation(ppt_file)
 
        # Collect text from all slides and shapes
        slides_text = []
        for i, slide in enumerate(presentation.slides, start=1):
            slide_text = ""
            for shape in slide.shapes:
                if hasattr(shape, "text_frame") and shape.text_frame:
                    slide_text += shape.text
            slides_text.append(f"Page number {i}\n{slide_text}")
        return slides_text
 
    except Exception as e:
        return f"Error extracting PPT content: {str(e)}"
# ---------------------------------------------------------------------------
# 1.  Tell pytesseract where the engine is � once, at import time
# ---------------------------------------------------------------------------


# 2.  Fail fast if that binary is still not reachable
if not shutil.which(pytesseract.pytesseract.tesseract_cmd):
    raise RuntimeError(
        f"Tesseract not found at {pytesseract.pytesseract.tesseract_cmd}. "
        "Fix the path above."
    )

logging.info("Tesseract CMD pinned to: %s", pytesseract.pytesseract.tesseract_cmd)



def convert_pdf(content: bytes, *, dpi: int = 300, lang: str = "ara+eng") -> str:
    """
    Extracts text from a PDF, using fast direct extraction for digital PDFs,
    and OCR fallback for scanned/image-only PDFs.

    Args:
    ----
    content : bytes
        The PDF binary.
    dpi     : int
        Resolution for rasterizing images if OCR is needed.
    lang    : str
        Tesseract language codes (e.g., "ara", "eng", or "ara+eng").

    Returns:
    -------
    str
        Combined text from all pages.
    """
    doc = fitz.open(stream=content, filetype="pdf")

    pages = []

    for i in range(len(doc)):
        page = doc[i]

        text = page.get_text().strip()

        if not text:
            try:
                # Render only this page as image to save memory
                img = convert_from_bytes(
                    content,
                    dpi=dpi,
                    fmt="png",
                    first_page=i + 1,
                    last_page=i + 1,
                    poppler_path = poppler_path
                )[0]

                ocr_text = pytesseract.image_to_string(img, lang=lang, config="--psm 6").strip()
                pages.append(f"--- Page Number {i + 1} ---\n{ocr_text}")
                print("ocr text", ocr_text)

            except Exception as e:
                pages.append(f"[ERROR OCR page {i + 1}] {e}")
            
        else:
            pages.append(f"Page Number {i + 1} \n{text}")


    return pages

