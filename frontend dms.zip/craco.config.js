module.exports = {
  devServer: {
    port: 3000,
    host: "0.0.0.0",
    allowedHosts: "all",
  },
  webpack: {
    configure: (webpackConfig, { env, paths }) => {
      // Ensure proper public path for production builds
      if (env === 'production') {
        webpackConfig.output.publicPath = './';
      }
      return webpackConfig;
    },
  },
  // Configure for production builds
  ...(process.env.NODE_ENV === 'production' && {
    webpack: {
      configure: (webpackConfig) => {
        webpackConfig.output.publicPath = './';
        return webpackConfig;
      },
    },
  }),
};